﻿using Microsoft.EntityFrameworkCore;
using RestaurantProject_Jp.DataAccessLayer;
using RestaurantProject_Jp.Models;

namespace RestaurantProject_Jp.Repository
{
    public class FoodRepository : IFoodRepository
    {
        private readonly EmployeeContext _appDBContext;
        private EmployeeContext context;

        public FoodRepository(EmployeeContext context)
        {
            this.context = context;
           // _appDBContext = context ??
            throw new ArgumentNullException(nameof(context));
        }

        public bool DeleteFood(int FoodId)
        {
            var food = _appDBContext.Foods.Find(FoodId);
            bool result;
            if (food != null)
            {
                _appDBContext.Entry(food).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<IEnumerable<Food>> GetOrder()
        {
            return await _appDBContext.Foods.ToListAsync();
        }
        public async Task<Food> GetFoodById(int FoodId)
        {
            return await _appDBContext.Foods.FindAsync(FoodId);
        }

        public async Task<Food> InsertFood(Food objFood)
        {
            _appDBContext.Foods.Add(objFood);
            await _appDBContext.SaveChangesAsync();
            return objFood;
        }

        public async Task<Food> Update(Food objFood)
        {
            _appDBContext.Entry(objFood).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objFood;
        }

        public async Task<IEnumerable<Food>> GetPrice()
        {
            return await _appDBContext.Foods.ToListAsync();
        }
    }
}
