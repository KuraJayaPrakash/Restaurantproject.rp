﻿using RestaurantProject_Jp.Models;

namespace RestaurantProject_Jp.Repository
{
    public interface IOrderRepository
    {
        
            Task<IEnumerable<Order>> GetOrder();
            Task<IEnumerable<Order>> GetPrice();
            Task<Order> GetOrderById(int OrderId);
            Task<Order> InsertOrder(Order objOrder);
            Task<Order> Update(Order objOrder);
            bool DeleteOrder(int OrderId);
        }
}
