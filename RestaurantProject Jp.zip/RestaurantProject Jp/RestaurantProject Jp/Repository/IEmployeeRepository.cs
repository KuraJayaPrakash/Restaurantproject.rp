﻿using RestaurantProject_Jp.Models;

namespace RestaurantProject_Jp.Repository
    
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<Employee>> GetEmployee();
        Task<Employee> GetEmployeeById(int ID);
        Task<Employee> InsertEmployee(Employee objEmployee);
        Task<Employee> Update(Employee objEmployee);
        bool DeleteEmployee(int ID);
      
    }
}
