﻿
using Microsoft.EntityFrameworkCore;
using RestaurantProject_Jp.DataAccessLayer;
using RestaurantProject_Jp.Repository;

namespace RestaurantProject_Jp.Models
{
    public class EmployeeRepository : IEmployeeRepository
    {
         
        private readonly EmployeeContext _appDBContext;
        public EmployeeRepository(EmployeeContext context)
        {
            _appDBContext = context ??
            throw new ArgumentNullException(nameof(context));
        }

        
            
        public async Task<IEnumerable<Employee>> GetEmployee()
        {
            return await _appDBContext.Employees.ToListAsync();
        }

        public async Task<Employee> GetEmployeeById(int ID)
        {
            return await _appDBContext.Employees.FindAsync(ID);
        }

        public async Task<Employee> InsertEmployee(Employee objEmployee)
        {
            _appDBContext.Employees.Add(objEmployee);
            await _appDBContext.SaveChangesAsync();
            return objEmployee;
        }

        public async Task<Employee> Update(Employee objEmployee)
        {
            _appDBContext.Entry(objEmployee).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objEmployee;
        }

        public bool DeleteEmployee(int ID)
        {
            var employee = _appDBContext.Employees.Find(ID);
            bool result;
            if (employee != null)
            {
                _appDBContext.Entry(employee).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;

        }


        

        
       
    }
}
        
        