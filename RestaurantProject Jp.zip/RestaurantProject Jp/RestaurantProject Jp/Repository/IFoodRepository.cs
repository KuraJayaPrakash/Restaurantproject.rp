﻿using RestaurantProject_Jp.Models;

namespace RestaurantProject_Jp.Repository
{
    public interface IFoodRepository
    {
        Task<IEnumerable<Food>> GetOrder();
        Task<IEnumerable<Food>> GetPrice();
        Task<Food> GetFoodById(int FoodId);
        Task<Food> InsertFood(Food objFood);
        Task<Food> Update(Food objFood);
        bool DeleteFood(int FoodId);
    }
}
