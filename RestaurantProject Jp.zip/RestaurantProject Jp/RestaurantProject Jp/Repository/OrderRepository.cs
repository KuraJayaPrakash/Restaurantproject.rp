﻿using Microsoft.EntityFrameworkCore;
using RestaurantProject_Jp.DataAccessLayer;
using RestaurantProject_Jp.Models;

namespace RestaurantProject_Jp.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly EmployeeContext _appDBContext;
        public OrderRepository(EmployeeContext context)
        {
            _appDBContext = context ??
            throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteOrder(int OrderId)
        {
            var Order = _appDBContext.Orders.Find(OrderId);
            bool result;
            if (Order != null)
            {
                _appDBContext.Entry(Order).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<IEnumerable<Order>> GetOrder()
        {
            return await _appDBContext.Orders.ToListAsync();
        }

        public async Task<Order> GetOrderById(int OrderId)
        {
            return await _appDBContext.Orders.FindAsync(OrderId);
        }

        public async Task<IEnumerable<Order>> GetPrice()
        {
            return await _appDBContext.Orders.ToListAsync();
        }

        public async Task<Order> InsertOrder(Order objOrder)
        {
            _appDBContext.Orders.Add(objOrder);
            await _appDBContext.SaveChangesAsync();
            return objOrder;
        }

        public async Task<Order> Update(Order objOrder)
        {
            _appDBContext.Entry(objOrder).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objOrder;
        }
    }
}