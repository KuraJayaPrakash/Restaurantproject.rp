﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantProject_Jp.Models;
using RestaurantProject_Jp.Repository;

namespace RestaurantProject_Jp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodController : ControllerBase
    {
        private readonly IFoodRepository _food;
        public FoodController(IFoodRepository food)
        {
            _food = food ??
            throw new ArgumentNullException(nameof(food));
        }
        [HttpGet]
        [Route("GetFood")]
        public async Task<IActionResult> GetFood()
        {
            return Ok(await _food.GetOrder());
        }
        [HttpGet]
        [Route("GetPrice")]
        public async Task<IActionResult> GetPrice()
        {
            return Ok(await _food.GetPrice());
        }
        [HttpGet]
        [Route("GetFoodByID/{Id}")]
        public async Task<IActionResult> GetFoodById(int FoodId)
        {
            return Ok(await _food.GetFoodById(FoodId));
        }
        [HttpPost]
        [Route("InsertFood")]
        public async Task<IActionResult> Post(Food food)
        {
            var result = await _food.InsertFood(food);
            if (result.FoodId == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateFood")]
        public async Task<IActionResult> Put(Food food)
        {
            await _food.Update(food);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        
        [Route("DeleteFood")]
        public JsonResult Delete(int FoodId)
        {
            _food.DeleteFood(FoodId);
            return new JsonResult("Deleted Successfully");
        }
    }
}
