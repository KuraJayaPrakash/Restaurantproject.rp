﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantProject_Jp.Models;
using RestaurantProject_Jp.Repository;

namespace RestaurantProject_Jp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _employee;
        public EmployeeController(IEmployeeRepository employee)
        {
            _employee = employee ??
            throw new ArgumentNullException(nameof(employee));
        }
        [HttpGet]
        [Route("GetEmployee")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _employee.GetEmployee());
        }
        [HttpGet]
        [Route("GetEmployeeByID/{Id}")]
        public async Task<IActionResult> GetEmployeeById(int ID)
        {
            return Ok(await _employee.GetEmployeeById(ID));
        }
        [HttpPost]
        [Route("InsertEmployee")]
        public async Task<IActionResult> Post(Employee employee)
        {
            var result = await _employee.InsertEmployee(employee);
            if (result.EmpId == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateEmployee")]
        public async Task<IActionResult> Put(Employee employee)
        {
            await _employee.Update(employee);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        [Route("DeleteEmployee")]
        public JsonResult Delete(int ID)
        {
            _employee.DeleteEmployee(ID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
