﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantProject_Jp.Models;
using RestaurantProject_Jp.Repository;

namespace RestaurantProject_Jp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderss;
        public OrderController(IOrderRepository orderss)
        {
            _orderss = orderss ??
            throw new ArgumentNullException(nameof(orderss));
        }
        [HttpGet]
        [Route("GetOrder")]
        public async Task<IActionResult> GetOrder()
        {
            return Ok(await _orderss.GetOrder());
        }
        [HttpGet]
        [Route("GetPrice")]
        public async Task<IActionResult> GetPrice()
        {
            return Ok(await _orderss.GetPrice());
        }
        [HttpGet]
        [Route("GetFoodByID/{Id}")]
        public async Task<IActionResult> GetOrderById(int OrderId)
        {
            return Ok(await _orderss.GetOrderById(OrderId));
        }
        [HttpPost]
        [Route("InsertOrder")]
        public async Task<IActionResult> Post(Order orderss)
        {
            var result = await _orderss.InsertOrder(orderss);
            if (result.OrderId == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateFood")]
        public async Task<IActionResult> Put(Order orderss)
        {
            await _orderss.Update(orderss);
            return Ok("Updated Successfully");
        }
        [HttpDelete]

        [Route("DeleteOrder")]
        public JsonResult Delete(int OrderId)
        {
            _orderss.DeleteOrder(OrderId);
            return new JsonResult("Deleted Successfully");
        }
    }
}
