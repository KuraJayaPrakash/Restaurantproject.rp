﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantProject_Jp.Models
{
    [Table("Employee")]
    public class Employee
    {

        [Key]
            public int EmpId { get; set; }
            public string EmpName { get; set; }
            public string EmpPosition { get; set; }
        
       
       

    }

}
