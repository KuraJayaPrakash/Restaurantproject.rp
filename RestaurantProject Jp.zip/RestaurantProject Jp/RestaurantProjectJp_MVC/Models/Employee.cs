﻿namespace RestaurantProjectJp_MVC.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpPosition { get; set; }
    }
}
