﻿namespace RestaurantProjectJp_MVC.Models
{
    public class Food
    {
        public int FoodId { get; set; }
        public string FoodName { get; set; }
        public string FoodType { get; set; }
        public int Price { get; set; }
    }
}
