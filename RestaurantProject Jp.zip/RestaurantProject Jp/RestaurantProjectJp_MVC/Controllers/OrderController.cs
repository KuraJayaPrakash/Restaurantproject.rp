﻿using Microsoft.AspNetCore.Mvc;

namespace RestaurantProjectJp_MVC.Controllers
{
    public class OrderController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
