﻿using Microsoft.AspNetCore.Mvc;
using RestaurantProjectJp_MVC.Models;
using System.Net;
namespace RestaurantProjectJp_MVC.Controllers
{
    public class EmployeeController : Controller
    {
        [HttpGet]
        public IActionResult GetEmployee()
        {
            IEnumerable<Employee> Employees = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:59544");
                var responseTask = client.GetAsync("Employee");
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait(); Employees = readTask.Result;
                }
                else
                {
                    Employees = Enumerable.Empty<Employee>();
                    ModelState.AddModelError(string.Empty, "Server error can you please try after some time.");
                }
                return View();
            }
            var responseTask = client.GetAsync("Employees");
        }
    }
}