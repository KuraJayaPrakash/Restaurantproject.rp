﻿using Microsoft.AspNetCore.Mvc;

namespace RestaurantProjectJp_MVC.Controllers
{
    public class FoodController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
